package it.uniroma3.siw.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.model.Ricetta;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.service.RicettaService;
import it.uniroma3.siw.service.UserService;
import utils.FileUploadUtil;

@Controller
public class RicettaController {

    @Autowired
    private RicettaService ricettaService;

    @Autowired
    private UserService userService;
   
    @Autowired
    private GlobalController globalController;

    
    
    /*visualizza ricetta e ricette*/

    
    @GetMapping("/ricetta/{id}")
    public String getRicetta(@PathVariable("id") Long id,Model model) {
        model.addAttribute("ricetta", ricettaService.findById(id));
    	return "ricetta.html";
    }
    
    
    @GetMapping("/ricette")
    public String getAllRicette(Model model) {
        model.addAttribute("tutte_ricette", ricettaService.getAllRicette());

    	return "ricette.html";
    }
    
    /*aggiungi ricetta*/
    
    @GetMapping("/ricetta/new")
    public String showAddRicettaForm(@RequestParam("userId") Long userId, Model model) {
        User utente = userService.getUserById(userId);
        if(utente!=null) {
        model.addAttribute("utente", utente);
        model.addAttribute("userId", userId); // Aggiungi userId al modello
        model.addAttribute("ricetta", new Ricetta());
        return "add-ricetta";
        }else
        	return "redirect:/";
    }

    @PostMapping("/ricetta/new")
    public String addRicetta(@ModelAttribute("ricetta") Ricetta ricetta, @RequestParam("userId") Long userId, Model model) {
        User utente = userService.getUserById(userId);

        if (utente != null) {
            ricettaService.saveRicetta(ricetta, utente);
            return "success-ricetta";
        } else {
            model.addAttribute("error", "User not found");
            return "add-ricetta";
        }
    }
    
    
    
    /*modifica ricetta */
    
    
    @GetMapping("/ricetta/pagina/{id}")
    public String ricettaPaginaModifica(@PathVariable("id") Long id,Model model) {
    	User user = globalController.getCurrentUser();
    	Ricetta ricetta = ricettaService.findById(id);
    	
    	if(ricetta.getUtente().equals(user)) {
            model.addAttribute("user", user);
            model.addAttribute("user_id", user.getId());
            model.addAttribute("ricetta", ricetta);
            return "scheda-ricetta";
        } else {
            return "redirect:/login";
        }
    }
     
        

    @PostMapping("/ricetta/update/{ricettaId}")
    public String updateRicetta(@PathVariable("ricettaId") Long ricettaId, @ModelAttribute("ricetta") Ricetta ricettaForm, Model model) {
        User utente = globalController.getCurrentUser();
        Ricetta ricetta = ricettaService.findById(ricettaId);

        if (ricetta != null && ricetta.getUtente().equals(utente)) {
            // Aggiorna i campi della ricetta con i valori provenienti dal form
            ricetta.setNome(ricettaForm.getNome());
            ricetta.setDescrizione(ricettaForm.getDescrizione());
            
            // Mantieni l'utente che ha creato la ricetta
            ricetta.setUtente(utente);

            // Salva la ricetta aggiornata
            ricettaService.saveRicetta(ricetta, ricetta.getUtente());
            model.addAttribute("user", utente);
            model.addAttribute("ricetta", ricetta);
            model.addAttribute("user_id", utente.getId());
            return "scheda-ricetta";
        } else {
            model.addAttribute("error", "User not authorized or recipe not found");
            return "redirect:/login";
        }
    }

    
    
    /*cancella ricetta*/
    
    @PostMapping("/delete/{id}")
    public String deleteRicetta(@PathVariable("id") Long id,Model model) throws IOException {
        User user= globalController.getCurrentUser();
        Ricetta ricetta = ricettaService.findById(id);
        if(ricetta.getUtente().equals(user)) {
            List<String> fotoRicetta = ricetta.getRicettaPictures();
            String uploadDir = "src/main/resources/static/images";
            for (String foto : fotoRicetta) {
                FileUploadUtil.deleteFile(uploadDir, foto);
            }	
    	ricettaService.deleteById(id);
        }
        return "redirect:/user";
    }
    
   
    
    
   /*immagini*/ 
    
    
    
    @PostMapping("/user/ricetta/savePhoto/{ricettaId}")
    public String saveRicettaPhoto(@RequestParam("image") MultipartFile multipartFile, @PathVariable Long ricettaId) throws IOException {
        // Ottieni l'utente autenticato
        User user = globalController.getCurrentUser();
        Ricetta ricetta = ricettaService.findById(ricettaId);

        if (ricetta != null && ricetta.getUtente().getId().equals(user.getId())) {
            String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
            ricetta.getRicettaPictures().add(fileName);
            
            // Salva la ricetta aggiornata
            ricettaService.saveRicetta(ricetta, user);

            String uploadDir = "src/main/resources/static/images";
            FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);

            return "redirect:/";
        }
        return "redirect:/";
    }
    
 
    /**
     * Metodo per rimuovere una foto da una ricetta esistente.
     * 
     * @param imageName Il nome dell'immagine da rimuovere.
     * @param ricettaId ID della ricetta da cui rimuovere l'immagine.
     * @param model     Oggetto Model per passare attributi alla vista.
     * @return Redirect alla pagina di modifica della ricetta.
     * @throws IOException In caso di errori durante l'eliminazione del file.
     */
    @PostMapping("/user/ricetta/removePhoto/{ricettaId}")
    public String removeRicettaPhoto(@RequestParam("image") String imageName, @PathVariable("ricettaId") Long ricettaId, Model model) throws IOException {
        Ricetta ricetta = ricettaService.findById(ricettaId);
        if (ricetta != null) {
            ricetta.getRicettaPictures().remove(imageName);
            String uploadDir = "src/main/resources/static/images";
            FileUploadUtil.deleteFile(uploadDir, imageName);
            ricettaService.saveRicetta(ricetta,ricetta.getUtente()); // Assicurati di salvare le modifiche alla ricetta
            return "redirect:/ricetta/pagina/" + ricetta.getId();
        }
        return "redirect:/";
    }
    /*OPERAZIONI ADMIN*/
    
    @GetMapping("/admin/formUpdateRicetta/{id}")
    public String adminFormUpdateRicetta(@PathVariable("id") Long id, Model model) {
        Ricetta ricetta = this.ricettaService.findById(id);
        if (ricetta != null) {
            model.addAttribute("ricetta", ricetta);
          
            return "formUpdateRicetta";
        } else {
            model.addAttribute("error", "Ricetta non trovata");
            return "redirect:/admin/all_user";
        }
    }

    
    @GetMapping("/admin/ricetta/{id}")
    public String getRicettaAdmin(@PathVariable("id") Long id, Model model) {
        model.addAttribute("ricetta", ricettaService.findById(id));
        return "admin/admin-ricetta.html";
    }

    @GetMapping("/admin/ricette")
    public String getAllRicetteAdmin(Model model) {
        model.addAttribute("tutte_ricette", ricettaService.getAllRicette());
        return "admin/admin-ricette.html";
    }

    @GetMapping("/admin/ricetta/new")
    public String showAddRicettaFormAdmin(@RequestParam("userId") Long userId, Model model) {
        User utente = userService.getUserById(userId);
        if (utente != null) {
            model.addAttribute("utente", utente);
            model.addAttribute("userId", userId);
            model.addAttribute("ricetta", new Ricetta());
            return "admin/admin-add-ricetta";
        } else {
            return "redirect:/";
        }
    }

    @PostMapping("/admin/ricetta/new")
    public String addRicettaAdmin(@ModelAttribute("ricetta") Ricetta ricetta, @RequestParam("userId") Long userId, Model model) {
        User utente = userService.getUserById(userId);
        if (utente != null) {
            ricettaService.saveRicetta(ricetta, utente);
            return "admin/admin-success-ricetta";
        } else {
            model.addAttribute("error", "User not found");
            return "admin/admin-add-ricetta";
        }
    }
    
    @GetMapping("/admin/ricetta/pagina/{id}")
    public String ricettaPaginaModificaAdmin(@PathVariable("id") Long id, Model model) {
        User user = globalController.getCurrentUser();
        Ricetta ricetta = ricettaService.findById(id);
        
            model.addAttribute("user", user);
            model.addAttribute("user_id", user.getId());
            model.addAttribute("ricetta", ricetta);
            return "admin/admin-scheda-ricetta";
        
    }

    @PostMapping("/admin/ricetta/update/{ricettaId}")
    public String updateRicettaAdmin(@PathVariable("ricettaId") Long ricettaId, @ModelAttribute("ricetta") Ricetta ricettaForm, Model model) {
        User utente = globalController.getCurrentUser();
        Ricetta ricetta = ricettaService.findById(ricettaId);
        if (ricetta != null) {
            ricetta.setNome(ricettaForm.getNome());
            ricetta.setDescrizione(ricettaForm.getDescrizione());
            ricetta.setUtente(ricetta.getUtente());
            ricettaService.saveRicetta(ricetta, ricetta.getUtente());
            model.addAttribute("user", utente);
            model.addAttribute("ricetta", ricetta);
            model.addAttribute("user_id", utente.getId());
            return "admin/admin-scheda-ricetta";
        } else {
            model.addAttribute("error", "User not authorized or recipe not found");
            return "redirect:/admin/login";
        }
    }
    @PostMapping("/admin/delete/{id}")
    public String deleteRicettaAdmin(@PathVariable("id") Long id, Model model) throws IOException {
        Ricetta ricetta = ricettaService.findById(id);
        
            List<String> fotoRicetta = ricetta.getRicettaPictures();
            String uploadDir = "src/main/resources/static/images";
            for (String foto : fotoRicetta) {
                FileUploadUtil.deleteFile(uploadDir, foto);
            }	
            ricettaService.deleteById(id);
        
        return "redirect:/admin/ricette";
    }

    @PostMapping("/admin/user/ricetta/savePhoto/{ricettaId}")
    public String saveRicettaPhotoAdmin(@RequestParam("image") MultipartFile multipartFile, @PathVariable Long ricettaId) throws IOException {
        User user = globalController.getCurrentUser();
        Ricetta ricetta = ricettaService.findById(ricettaId);
        if (ricetta != null && ricetta.getUtente().getId().equals(user.getId())) {
            String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
            ricetta.getRicettaPictures().add(fileName);
            ricettaService.saveRicetta(ricetta, user);
            String uploadDir = "src/main/resources/static/images";
            FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
            return "redirect:/";
        }
        return "redirect:/";
    }

    @PostMapping("/admin/user/ricetta/removePhoto/{ricettaId}")
    public String removeRicettaPhotoAdmin(@RequestParam("image") String imageName, @PathVariable("ricettaId") Long ricettaId, Model model) throws IOException {
        Ricetta ricetta = ricettaService.findById(ricettaId);
        if (ricetta != null) {
            ricetta.getRicettaPictures().remove(imageName);
            String uploadDir = "src/main/resources/static/images";
            FileUploadUtil.deleteFile(uploadDir, imageName);
            ricettaService.saveRicetta(ricetta, ricetta.getUtente());
            return "redirect:/admin/ricetta/pagina/" + ricetta.getId();
        }
        return "redirect:/";
    }


    
}
