package it.project.controller;

import java.io.IOException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import it.project.model.*;

import it.project.service.CredentialsService;
import it.project.service.UserService;
import it.project.utils.*;

@Controller
public class UtenteController {
	
    @Autowired
    private UserService userService;
   
    @Autowired
    private GlobalController globalController;
    
    @Autowired
    private CredentialsService credentialsService;
    
    
    /**
     * Metodo per visualizzare la pagina di un singolo utente.
     * 
     * @param utenteId ID dell'utente da visualizzare.
     * @param utente   Oggetto utente da associare al modello.
     * @param model    Oggetto Model per passare attributi alla vista.
     * @return Il nome del template HTML per la visualizzazione dell'utente.
     */
    @GetMapping("/utente/{id}")
    private String PaginaUtente(@PathVariable("id") Long utenteId, @ModelAttribute("utente") User utente, Model model) {       
        model.addAttribute("utenteVisualizzato", this.userService.getUserById(utenteId));
        model.addAttribute("utente", utente);
        return "utente.html";
    }

    
    @GetMapping("/utenti")
    public String getAllUser(Model model) {
        model.addAttribute("tutti_utenti", userService.getAllUsers());

    	return "utenti.html";
    }
	
    @PostMapping("/user/savePhoto")
    public String saveUserPhoto(@RequestParam("image") MultipartFile multipartFile, RedirectAttributes redirectAttributes) throws IOException {
        if (multipartFile.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
            
        }

        // Ottieni l'utente autenticato
        
        User user = globalController.getCurrentUser();



        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        user.setPicture(fileName);
        
        // Salva l'utente aggiornato
        userService.saveUser(user);

        String uploadDir = "src/main/resources/static/images";
        FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);

        redirectAttributes.addFlashAttribute("message", "You successfully uploaded '" + fileName + "'");

        return "index";
    }
	

	@RequestMapping(value = "/admin/rimuoviFotoProfilo/{id}", method = RequestMethod.GET)
	public String removeUserPhoto(@PathVariable("id") Long id, Model model) {
		String fileName=userService.getUserById(id).getPicture();
		String uploadDir = "src/main/resources/static/images";
		try {
			FileUploadUtil.deleteFile(uploadDir, fileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		userService.saveUser(userService.getUserById(id));

		return "index";
	}
	
	@RequestMapping(value = "/admin/utenti", method = RequestMethod.GET)
    public String getAllUserAdmin(Model model) {
    	
        model.addAttribute("tutti_utenti", userService.getAllUsers());
        
    	return "admin/pagina_utente_amministratore/adminUtentiRegistrati.html";
    }
    
    @PostMapping("/admin/remove/user/{utenteid}")
    public String removeUserAdmin(@PathVariable("utenteid") Long id,Model model) {
    	User user = userService.getUserById(id);  	
         
         credentialsService.deleteByUser(user);
         
        model.addAttribute("tutti_utenti", userService.getAllUsers());
    	return "admin/pagina_utente_amministratore/utenti.html";
    }
}
