package it.project.repository;

import org.springframework.data.repository.CrudRepository;

import it.project.model.Gatto;

public interface GattoRepository extends CrudRepository<Gatto, Long>{

}
