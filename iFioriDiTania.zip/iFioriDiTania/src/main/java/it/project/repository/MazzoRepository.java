package it.project.repository;


import org.springframework.data.repository.CrudRepository;

import it.project.model.Mazzo;

public interface MazzoRepository extends CrudRepository<Mazzo, Long>{

}
