package it.project.repository;

import org.springframework.data.repository.CrudRepository;

import it.project.model.Recensione;



public interface RecensioneRepository extends CrudRepository<Recensione, Long>{

}
