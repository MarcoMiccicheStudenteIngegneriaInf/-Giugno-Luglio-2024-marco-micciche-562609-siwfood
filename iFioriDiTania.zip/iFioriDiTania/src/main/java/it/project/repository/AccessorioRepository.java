package it.project.repository;

import org.springframework.data.repository.CrudRepository;

import it.project.model.Accessorio;

public interface AccessorioRepository extends CrudRepository<Accessorio, Long>{

}
