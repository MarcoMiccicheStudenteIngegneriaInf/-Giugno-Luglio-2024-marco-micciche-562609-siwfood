package it.project.repository;

import org.springframework.data.repository.CrudRepository;

import it.project.model.Servizio;

public interface ServizioRepository extends CrudRepository<Servizio, Long>{

}
